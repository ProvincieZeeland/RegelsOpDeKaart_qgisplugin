def classFactory(iface):
    from .RuimtelijkePlannen import RuimtelijkePlannen
    return RuimtelijkePlannen(iface)
